# Imports
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

import numpy as np
import tensorflow as tf
physical_devices = tf.config.experimental.list_physical_devices('GPU')
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)

from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Model
from tensorflow.keras.applications import vgg16
from tensorflow import keras
from datetime import datetime
def print_with_time(*args,**kwargs):
    print(str(datetime.now())+'[{}]:'.format(__file__), *args, **kwargs)

# Hyperparams
style_weight = 0.002
content_weight = 1.0
variation_weight = 0.0
learning_rate = 5.
ITERATIONS = 100

# Paths
content_image_path = "SanFrancisco.jpg"               # San Francisco
style_image_path = "WarsawByTytusBrzozowski.jpg"    # Warsaw by Tytus Brzozowski

IMAGENET_MEAN_RGB_VALUES = [123.68, 116.779, 103.939]

# Content layer where will pull our feature maps
content_layers = ['block2_conv2']
# Style layer of interest
style_layers = ["block1_conv2", "block2_conv2", "block3_conv3", "block4_conv3", "block5_conv3"]

# weight normalization
# weight_sum = style_weight + content_weight + variation_weight
# style_weight /= weight_sum
# content_weight /= weight_sum
# variation_weight /= weight_sum

# Content Image
content_image = image.load_img(content_image_path)
content_image = image.img_to_array(content_image)
content_image = np.expand_dims(content_image, axis=0)
content_image_processed = vgg16.preprocess_input(content_image.copy())

# Style Image
style_image = image.load_img(style_image_path)
style_image = image.img_to_array(style_image)
style_image = np.expand_dims(style_image, axis=0)
style_image_processed = vgg16.preprocess_input(style_image.copy())

# CNN Model
vgg_network = vgg16.VGG16(weights='imagenet', include_top=False)
vgg_network.trainalbe = False


def gram_matrix(input_tensor):
  result = tf.linalg.einsum('bijc,bijd->bcd', input_tensor, input_tensor)
  input_shape = tf.shape(input_tensor)
  num_locations = tf.cast(input_shape[1]*input_shape[2], tf.float32)
  return result/(num_locations)

style_extractor = keras.Model([vgg_network.input],
    [gram_matrix(vgg_network.get_layer(name).output) for name in style_layers])
content_extractor = keras.Model([vgg_network.input],
    [vgg_network.get_layer(name).output for name in content_layers])

output_image = tf.Variable(content_image_processed)
opt = tf.optimizers.Adam(learning_rate=learning_rate)


# G(style_image)
style_targets = style_extractor(style_image_processed)
# F(content_image)
content_targets = content_extractor(content_image_processed)

def train_step():
    with tf.GradientTape() as tape:
        # G(output_image)
        style_of_output = style_extractor(output_image)
        # F(output_image)
        content_of_output = content_extractor(output_image)

        # style loss
        style_loss = [tf.reduce_mean((output - target) ** 2)
                        for output,target in zip(style_of_output, style_targets)]
        style_loss = style_weight * tf.reduce_mean(style_loss)

        # content loss
        content_loss = [tf.reduce_mean((output - target) ** 2)
                            for output,target in zip(content_of_output, content_targets)]
        content_loss = content_weight * tf.reduce_mean(content_loss)

        # variation loss
        x_deltas, y_deltas = 0., 0.
        for i in range(5):
            x_deltas += (output_image[:, :, i:-5+i, :] - output_image[:, :, 5:, :])
            y_deltas += (output_image[:, i:-5+i, :, :] - output_image[:, 5:, :, :])
        variation_loss =  variation_weight * (tf.reduce_sum(tf.abs(x_deltas)) + tf.reduce_sum(tf.abs(y_deltas)))

        loss = style_loss + content_loss + variation_loss

    print_with_time("| {:10.1f} | {:10.1f} | {:12.1f} | {:13.1f} |".format(
        loss.numpy(), style_loss.numpy(), content_loss.numpy(),
        variation_loss.numpy()))

    # minize the loss by the optimizer
    grad = tape.gradient(loss, output_image)
    opt.apply_gradients([(grad, output_image)])

print_with_time("| total_loss | style_loss | content_loss | variation_loss |")
for i in range(ITERATIONS+1):
    train_step()
    if i%10 == 0:
        file_name = "output{}.jpg".format(i)
        # depreprocess it
        output = output_image[0, :, :, ::-1]
        output = output.numpy()
        output += IMAGENET_MEAN_RGB_VALUES
        output[output<0.] = 0.
        output[output>255.] = 255
        image.array_to_img(output).save(file_name)
        print_with_time('save to ' + file_name)
