# Image Style Transfer
Neural style transfer is an optimization technique used to take two images—a content image and a style reference image (such as an artwork by a famous painter)—and blend them together so the output image looks like the content image, but “painted” in the style of the style reference image.

<center>

![style transfer](https://godatadriven.com/wp-content/images/how-to-style-transfer/style-transfer-example.jpg)
<p>Fig 1. Content image + Style image = Output image</p>
</center>

## Measure Content Difference
The content of an image is represented by the values of the intermediate feature maps. Denote the feature map function of a layer by $F(\cdot)$. We could measure the content difference directly between two images, $x_1,x_2$, by the mean squared loss between their intermediate feature maps in this layer:
$$ l_\text{content}(x_1, x_2) = \frac{||F(x_1)-F(x_2)||^2_2}{\text{size_of}(F)} $$
The less this loss is, the similar their contents will be.

## Measure Style Difference
### Calculate Style
It turns out, the style of an image can be described by the means and correlations across the different feature maps (Gram matrix).

Denote intermediate feature map of some layer in CNN by $F^l(x)$. The Gram matrix can be calcualted for this layer as:
$$G_{cd}(x) = \frac{\sum_{ij}F_{ijc}(x)F_{ijd}(x)}{IJ}$$
### Style Difference
Given two image $x_1$ and $x_2$, we can measure their style difference by the mean squared loss between their Gram matrix:
$$ l_\text{style}(x_1, x_2) = \frac{||G(x_1)-G(x_2)||^2_2}{\text{size_of}(G)} $$
The less this loss is, the similar their style will be.

## Total Loss
Our goal is to generate an image, that has same content as content image and same style as style image, so we define a loss as:
$$l(\text{img}_\text{gen}) = w_1* l_\text{content}(\text{img}_\text{gen}, \text{img}_\text{content}) + w_2*l_\text{style}(\text{img}_\text{gen}, \text{img}_\text{style}),$$
and then we minimize this loss to generate a new image:
$$\min_{\text{img}_\text{gen}} \; l(\text{img}_\text{gen})$$

## Result
The code is in `style_trans.py`. The program may take several hours to finish running, if no GPU available. The content image and style image we use is shown in Fig. 2.
<center>
<img src="SanFrancisco.jpg" alt="SanFrancisco.jpg" style="width:33%">
<img src="WarsawByTytusBrzozowski.jpg" alt="WarsawByTytusBrzozowski.jpg" style="width:56%">
<p>Fig 2. Content Image and Style Image.</p>
</center>

After minimization finishes, we got several output images:

<center>
<img src="output/output0.jpg" alt="output/output0.jpg" style="width:32%">
<img src="output/output100.jpg" alt="output/output100.jpg" style="width:32%">
<img src="output/output300.jpg" alt="output/output300.jpg" style="width:32%">
<img src="output/output600.jpg" alt="output/output600.jpg" style="width:32%">
<img src="output/output1000.jpg" alt="output/output1000.jpg" style="width:32%">
<img src="output/output1900.jpg" alt="output/output1900.jpg" style="width:32%">
<p>Fig 3. Results after 0/100/300/600/1000/1900 steps minimization.</p>
</center>

Along with minimization, the generated image becomes more and more like the style image. The result depends on hyper-parameters, including $w_1,w_2$. It usually takes time to find a set of proper hyper-parameters, that generates beautiful results.
